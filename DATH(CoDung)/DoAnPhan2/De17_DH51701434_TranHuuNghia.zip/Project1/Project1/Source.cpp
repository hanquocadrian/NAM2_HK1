#include"Header.h"
//int soluong = 0;
void Init( DSCNPTR &test) {
	test = NULL;
}
bool Empty(DSCNPTR test)
{
	return (test == NULL);
}
DSCN* tao1nodeCN(CANNHA a) {
	DSCN* p;
	p = new DSCN;
	p->data = a;
	p->link = NULL;
	return p;
}
CANNHA inputCN() {
	CANNHA a;
	cout << "\n Nhap vao ma nha ";
	cin.getline(a.manha, 20);
	cout << "\n Nhap vao dia chi: ";
	cin.getline(a.diachi, 30);
	cout << "\n Nhap vao dien tich: ";
	cin >> a.dientich;

	cout << "\n Nhap vao don gia: ";
	cin >> a.dongia;
	return a;
}

void nhapDSCN(DSCNPTR& test) {
	unsigned short int stt = 1;
	bool stop = 1;
	while (stop == 1) {
		cout << "\n--Nhap can nha thu " << stt << " ---";
		stt++;
		themusernhap(test);
		do {
			cout << "\nBan co muon nhap tiep khong (Yes = 1/No = 0) ?: ";
			cin >> stop;
			if (stop != 0 && stop != 1) {
				cout << "\nLua chon cua ban khong hop le ! Xin nhap so 1 de tiep tuc hoac 0 de dung !";
			}
		} while (stop != 0 && stop != 1);
		cin.ignore();
	};
}
void xuat1CN(CANNHA a) {
	cout << "\n\t Ma nha: " << a.manha;
	cout << "\n\t dia chi: " << a.diachi;
	cout << "\n\t Dien tich: " << a.dientich;
	cout << "\n\t Don gia: " << a.dongia;

	
		float ThanhTien = thanhtien( a);
	/*	float ThanhTien = thanhtien(a++);*/
	cout << "\n\tThanhTien:" << ThanhTien;
	float TongTien = thanhtien(a);
	cout << "\n\tTinhTongThanhTien :" << TongTien;
}
void xuatDSCN(DSCNPTR test) {
	unsigned short int stt = 1;
	while (test!= NULL) {
		cout << "\nCan nha thu " << stt << ":";
		xuat1CN(test->data);
		test = test->link;
		stt++;
	}
}
void themusernhap(DSCNPTR& test) {
	DSCNPTR p = new DSCN;
	p = tao1nodeCN(inputCN());
	if (test == NULL) test = p;
	else {
		p->link = test;
		test = p;
	}
}
void timtheomanha(DSCNPTR test, char *manha) {
	bool timthay = false;
	if (test == NULL) cout << "Danh sach khong co du lieu";
	else {
		DSCNPTR temp = new DSCN;
		temp = test;
		while (temp != NULL) {
			if (strcmp(manha, temp->data.manha) == 0) {
				xuat1CN(temp->data);
				timthay = true;
			}
			temp = temp->link;
		}
		if (timthay == false) cout << "Khong tim thay can nha co ma sach la " << manha;
	}
}
void timtheodiachi(DSCNPTR test, char* diachi) {
	bool timthay = false;
	if (test == NULL) cout << "Danh sach khong co du lieu";
	else {
		DSCNPTR temp = new DSCN;
		temp = test;
		while (temp != NULL) {
			if (strcmp(diachi, temp->data.diachi) == 0) {
				xuat1CN(temp->data);
				timthay = true;
			}
			temp = temp->link;
		}
		if (timthay == false) cout << "Khong tim thay can nha co dia chi la " << diachi;
	}
}

void xoaCNtheomanha(DSCNPTR& test, char* manha) {
	DSCNPTR temp = new DSCN;
	temp = test;
	DSCNPTR prev = new DSCN;
	prev = temp;
	bool flag = 0;
	if (test == NULL) cout << "/nDanh sach khong co du lieu ";
	else if (strcmp(test->data.manha, manha) == 0) {
		prev = test;
		test = test->link;
		delete prev;
		flag = 1;
	}
	else {
		while (temp != NULL) {
			if (strcmp(temp->data.manha, manha) == 0) {
				prev->link = temp->link;
				flag = 1;
			}
			prev = temp;
			temp = temp->link;
		}
		delete temp;
	}
	if (flag)
		cout << "\nDa xoa can nha co ma nha la " << manha;
	else
		cout << "\nDanh sach khong co ma nha la " << manha;
}
void xoaCNtheodiachi(DSCNPTR& test, char* diachi) {
	DSCNPTR temp = new DSCN;
	temp = test;
	DSCNPTR prev = new DSCN;
	prev = temp;
	bool flag = 0;
	if (test == NULL) cout << "/nDanh sach khong co du lieu ";
	else if (strcmp(test->data.diachi, diachi) == 0) {
		prev = test;
		test = test->link;
		delete prev;
		flag = 1;
	}
	else {
		while (temp != NULL)
		{
			if (strcmp(temp->data.diachi, diachi) == 0) {
				prev->link = temp->link;
				flag = 1;
			}
			prev = temp;
			temp = temp->link;
		}
		delete temp;
	}
	if (flag)
		cout << "\nDa xoa can nha co dia chi la " << diachi;
	else
		cout << "\nDanh sach khong co dia chi la " << diachi;
}
void hoanVi(CANNHA &a, CANNHA &b)
{
	CANNHA t = a;
	a = b;
	b = t;
}
bool sapXepTangDancannhaTheodientich(DSCNPTR test, DSCNPTR &newd)
{
	if (Empty(test))
		return false;
	else
	{
		newd =test;
		for (DSCNPTR i = newd; i->link != NULL; i = i->link)
		{
			for (DSCNPTR j = i->link; j != NULL; j = j->link)
			{
				if (i->data.dientich > j->data.dientich)
				{
					hoanVi(i->data, j->data);
				}
			}
		}
		return true;
	}
}
bool sapXepGiamDancannhaTheodientich(DSCNPTR test, DSCNPTR &newd)
{
	if (Empty(test))
		return false;
	else
	{
		newd = test;
		for (DSCNPTR i = newd; i->link != NULL; i = i->link)
		{
			for (DSCNPTR j = i->link; j != NULL; j = j->link)
			{
				if (i->data.dientich < j->data.dientich)
				{
					hoanVi(i->data, j->data);
				}
			}
		}
		return true;
	}
}
bool sapXepTangDancannhaTheodongia(DSCNPTR test, DSCNPTR &newd)
{
	if (Empty(test))
		return false;
	else
	{
		newd = test;
		for (DSCNPTR i = newd; i->link != NULL; i = i->link)
		{
			for (DSCNPTR j = i->link; j != NULL; j = j->link)
			{
				if (i->data.dongia > j->data.dongia)
				{
					hoanVi(i->data, j->data);
				}
			}
		}
		return true;
	}
}
bool sapXepGiamDancannhaTheodongia(DSCNPTR test, DSCNPTR &newd)
{
	if (Empty(test))
		return false;
	else
	{
		newd = test;
		for (DSCNPTR i = newd; i->link != NULL; i = i->link)
		{
			for (DSCNPTR j = i->link; j != NULL; j = j->link)
			{
				if (i->data.dongia < j->data.dongia)
				{
					hoanVi(i->data, j->data);
				}
			}
		}
		return true;
	}
}
float thanhtien(CANNHA a)
{
	float kq = 0;
		kq = (float)a.dongia*(float)a.dientich;
	return kq;
}
int tinhtong(DSCNPTR l)
{ 
	int tong = 0;
	for (DSCNPTR k = l; k != NULL; k = k->link)
	{
		tong += k->data.dongia * k->data.dientich;
	}
	return tong;
}
int dem(DSCNPTR l)
{
	int dem=0;
	for (DSCNPTR k = l; k != NULL; k = k->link)
		if (k->data.dongia % 1000 == 0)
			dem++;
	return dem;
}
//float tinhtongtien(DSCNPTR& a/*test*/)
//{
//	float tong = 0;
//	while (/*test*/ a !=NULL)
//	{
//		tong = tong + a->data.dongia*a->data.dientich;
//	}
//	return tong;
//}


void menu() {
	cout << "\n----------------------------------------";
	cout << "\n Nhap 1 so de lua chon phan  ";
	cout << "\n1. Nhap danh sach can nha";
	cout << "\n2. Xuat danh sach can nha";
	cout << "\n3. Them 1 can nha theo user nhap ";
	cout << "\n4. Tim kiem can nha ";
	cout << "\n5. Xoa can nha theo ma nha";
	cout << "\n6. Xoa can nha theo dia chi";
	cout << "\n7. sap xap can nha theo dien tich";
	cout << "\n8. sap xap can nha theo don gia";
	cout << "\n9. thanh tien";
	cout << "\n10. tong tien";
	cout << "\n11. dem";

    cout << "\n0. Thoat";
	//cout << "\n----------------------------------------";
}
void menuTim() {
	cout << "------------------------------";
	cout << "\n1. Tim theo ma nha";
	cout << "\n2. Tim theo dia chi";
	cout << "\n3. Quay lai";
	cout << "\n-----------------------------";
}
