#include<iostream>
using namespace std;
struct CANNHA {
	char manha[20];
	char diachi[30];
	unsigned short int dongia;
	unsigned short int dientich;
	
};
struct DSCN {
	CANNHA data;
	DSCN* link;
};
typedef DSCN* DSCNPTR;
void Init(DSCNPTR &a);
DSCN* tao1nodeCN(CANNHA a);
CANNHA inputCN();
bool Empty(DSCNPTR test);
void nhapDSCN(DSCNPTR& test);
void xuatDSCN(DSCNPTR test);
void xuat1CN(CANNHA a);
void themusernhap(DSCNPTR& test);
void timtheomanha(DSCNPTR test, char*manha);
void timtheomanha(DSCNPTR test, char* manha);
void timtheodiachi(DSCNPTR test, char* diachi);
void xoaCNtheomanha(DSCNPTR& test, char* manha);
void xoaCNtheodiachi(DSCNPTR& test, char* diachi);
bool sapXepTangDancannhaTheodientich(DSCNPTR test, DSCNPTR &newd);
bool sapXepGiamDancannhaTheodientich(DSCNPTR test, DSCNPTR &newd);
bool sapXepTangDancannhaTheodongia(DSCNPTR test, DSCNPTR &newd);
bool sapXepGiamDancannhaTheodongia(DSCNPTR test, DSCNPTR &newd);
float thanhtien(CANNHA a);
int tinhtong(DSCNPTR l);
int dem(DSCNPTR l);
void menu();
void menuTim();
