#include"Header.h"
void main()
{

	DSCNPTR test = new DSCN;

	char* xoamanha = new char[20];
	char* xoadiachi = new char[30];
	DSCNPTR sxtheodientich;
	DSCNPTR sxtheodongia;
	unsigned short int chon;
	float dongia;
	float dientich;
	/*int soluong;*/
	Init(test);

	do {
		menu();
		cout << "\nBan muon dung phan nao?:";
		cin >> chon;
		switch (chon) {
		case 1:
			system("cls");
			cin.ignore();
			nhapDSCN(test);
			break;
		case 2:
			system("cls");
			xuatDSCN(test);
			break;
		case 3:
			cin.ignore();
			themusernhap(test);
			break;
		case 4:
			system("cls");
			unsigned short int tieuchi;
			menuTim();
			cout << "\nTieu chi de tim can nha: ";
			cin >> tieuchi;
			if (tieuchi == 1) {
				char* timmanha = new char[20];
				cout << "\nNhap vao ma can nha can tim kiem: ";
				cin.ignore();
				cin.getline(timmanha, 20);
				timtheomanha(test, timmanha);

			}
			else if (tieuchi == 2) {
				char* timdiachi = new char[30];
				cout << "\nNhap vao don gia can tim kiem: ";
				cin.ignore();
				cin.getline(timdiachi, 30);
				timtheodiachi(test, timdiachi);

			}
			break;
		case 5:
			cout << "\nNhap vao ma nha can xoa: ";
			cin.ignore();
			cin.getline(xoamanha, 20);
			xoaCNtheomanha(test, xoamanha);
			break;
		case 6:
		{
			cout << "\nNhap vao dia chi can xoa: ";
			cin.ignore();
			cin.getline(xoadiachi, 30);
			xoaCNtheodiachi(test, xoadiachi);
			break;
		}
		case 7:
			if (Empty(test))
			{
				cout << "can nha Dang rong.";
				system("pause");
				break;
			}
			else
			{
				int chonsxdt;
				do {
					system("cls");
					cout << "\nBan muon sap xep nhu nao doi voi dien tich:";
					cout << "\n0.Thoat ra.";
					cout << "\n1.Tang Dan.";
					cout << "\n2.Giam Dan.";
					cout << "\nBan chon muc: ";
					cin >> chonsxdt;
					switch (chonsxdt)
					{
					case 0:
						break;
					case 1:
						cout << "\n1.Sap Xep Tang Dan can nha Theo: dien tich";
						if (sapXepTangDancannhaTheodientich(test, sxtheodientich))
						{
							cout << "\nSap Xep theo dien tich Tang Dan thanh cong.";
							xuatDSCN(sxtheodientich);
						}
						else
							cout << "\nDS dang rong khong the sap xep.";
						system("pause");
						break;
					case 2:
						cout << "\n2.Sap Xep Giam Dan can nha Theo: dien tich";
						if (sapXepGiamDancannhaTheodientich(test, sxtheodientich))
						{
							cout << "\nSap Xep theo dien tich  Giam Dan thanh cong.";
							xuatDSCN(sxtheodientich);
						}
						else
							cout << "\nDS dang rong khong the sap xep.";
						system("pause");
						break;
					default:
						break;
					}
				} while (chonsxdt != 0);
				break;
			}
		case 8:
			if (Empty(test))
			{
				cout << "can nha Dang rong.";
				system("pause");
				break;
			}
			else
			{
				int chonsxdg;
				do {
					system("cls");
					cout << "\nBan muon sap xep nhu nao doi voi don gia:";
					cout << "\n0.Thoat ra.";
					cout << "\n1.Tang Dan.";
					cout << "\n2.Giam Dan.";
					cout << "\nBan chon muc: ";
					cin >> chonsxdg;
					switch (chonsxdg)
					{
					case 0:
						break;
					case 1:
						cout << "\n1.Sap Xep can nha Tang Dan  Theo: don gia";
						if (sapXepTangDancannhaTheodongia(test, sxtheodongia))
						{
							cout << "\nSap Xep theo don gia Tang Dan thanh cong.";
							xuatDSCN(sxtheodongia);
						}
						else
							cout << "\nDS dang rong khong the sap xep.";
						system("pause");
						break;
					case 2:
						cout << "\n2.Sap Xep Giam Dan can nha Theo: dongia";
						if (sapXepGiamDancannhaTheodongia(test, sxtheodongia))
						{
							cout << "\nSap Xep theo don gia Giam Dan thanh cong.";
							xuatDSCN(sxtheodongia);
						}
						else
							cout << "\nDS dang rong khong the sap xep.";
						system("pause");
						break;
					default:
						break;
					}
				} while (chonsxdg != 0);
				break;
		case 10:
			cout << "thanh tien:" << tinhtong(test) << endl;
			break;
			}
		case 11:

			cout << "dem:" << dem(test) << endl;
			break;

		}
		
		
		} while (chon != 0);
	system("pause");
}